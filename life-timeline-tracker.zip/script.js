const products = [
    { name: "Parle-G Biscuits", price: 10, category: "Snacks", image: "https://dummyimage.com/300x220/fdd835/222&text=Parle-G" },
    { name: "Maggi Noodles", price: 15, category: "Snacks", image: "https://dummyimage.com/300x220/ffeb3b/222&text=Maggi" },
    { name: "Haldiram Bhujia", price: 55, category: "Snacks", image: "https://dummyimage.com/300x220/ffb74d/222&text=Bhujia" },
    { name: "Kurkure Masala Munch", price: 20, category: "Snacks", image: "https://dummyimage.com/300x220/ffcc80/222&text=Kurkure" },
    { name: "Lays Classic Chips", price: 30, category: "Snacks", image: "https://dummyimage.com/300x220/ffe082/222&text=Lays" },
    { name: "Good Day Cookies", price: 35, category: "Snacks", image: "https://dummyimage.com/300x220/d7ccc8/222&text=Good+Day" },
    { name: "Marie Gold Biscuits", price: 30, category: "Snacks", image: "https://dummyimage.com/300x220/fff3e0/222&text=Marie+Gold" },
    { name: "Murmura", price: 40, category: "Snacks", image: "https://dummyimage.com/300x220/fff8e1/222&text=Murmura" },

    { name: "India Gate Basmati Rice", price: 180, category: "Rice & Atta", image: "https://dummyimage.com/300x220/fff8e1/222&text=Basmati+Rice" },
    { name: "Sona Masoori Rice", price: 120, category: "Rice & Atta", image: "https://dummyimage.com/300x220/f5f5dc/222&text=Sona+Masoori" },
    { name: "Ponni Rice", price: 115, category: "Rice & Atta", image: "https://dummyimage.com/300x220/fafad2/222&text=Ponni+Rice" },
    { name: "Aashirvaad Atta", price: 250, category: "Rice & Atta", image: "https://dummyimage.com/300x220/d7ccc8/222&text=Atta" },
    { name: "Besan Flour", price: 75, category: "Rice & Atta", image: "https://dummyimage.com/300x220/ffe0b2/222&text=Besan" },
    { name: "Ragi Flour", price: 65, category: "Rice & Atta", image: "https://dummyimage.com/300x220/bcaAA4/222&text=Ragi+Flour" },
    { name: "Sooji Rava", price: 50, category: "Rice & Atta", image: "https://dummyimage.com/300x220/fffde7/222&text=Sooji" },
    { name: "Poha", price: 55, category: "Rice & Atta", image: "https://dummyimage.com/300x220/fff9c4/222&text=Poha" },

    { name: "Toor Dal", price: 140, category: "Dals & Pulses", image: "https://dummyimage.com/300x220/ffe082/222&text=Toor+Dal" },
    { name: "Moong Dal", price: 130, category: "Dals & Pulses", image: "https://dummyimage.com/300x220/fff176/222&text=Moong+Dal" },
    { name: "Chana Dal", price: 110, category: "Dals & Pulses", image: "https://dummyimage.com/300x220/ffd54f/222&text=Chana+Dal" },
    { name: "Urad Dal", price: 125, category: "Dals & Pulses", image: "https://dummyimage.com/300x220/e0e0e0/222&text=Urad+Dal" },
    { name: "Masoor Dal", price: 105, category: "Dals & Pulses", image: "https://dummyimage.com/300x220/ffab91/222&text=Masoor+Dal" },
    { name: "Kabuli Chana", price: 135, category: "Dals & Pulses", image: "https://dummyimage.com/300x220/f5deb3/222&text=Kabuli+Chana" },
    { name: "Rajma", price: 150, category: "Dals & Pulses", image: "https://dummyimage.com/300x220/a94442/fff&text=Rajma" },
    { name: "Black Chana", price: 115, category: "Dals & Pulses", image: "https://dummyimage.com/300x220/6d4c41/fff&text=Black+Chana" },

    { name: "Turmeric Powder", price: 45, category: "Spices", image: "https://dummyimage.com/300x220/ffc107/222&text=Turmeric" },
    { name: "Red Chilli Powder", price: 60, category: "Spices", image: "https://dummyimage.com/300x220/e53935/fff&text=Chilli+Powder" },
    { name: "Coriander Powder", price: 55, category: "Spices", image: "https://dummyimage.com/300x220/a5d6a7/222&text=Coriander" },
    { name: "Cumin Seeds", price: 85, category: "Spices", image: "https://dummyimage.com/300x220/bcaaa4/222&text=Cumin" },
    { name: "Mustard Seeds", price: 40, category: "Spices", image: "https://dummyimage.com/300x220/4e342e/fff&text=Mustard" },
    { name: "Garam Masala", price: 70, category: "Spices", image: "https://dummyimage.com/300x220/8d6e63/fff&text=Garam+Masala" },
    { name: "Sambar Powder", price: 65, category: "Spices", image: "https://dummyimage.com/300x220/d84315/fff&text=Sambar+Powder" },
    { name: "Cardamom", price: 180, category: "Spices", image: "https://dummyimage.com/300x220/a5d6a7/222&text=Cardamom" },

    { name: "Bru Coffee", price: 120, category: "Beverages", image: "https://dummyimage.com/300x220/8d6e63/fff&text=Bru+Coffee" },
    { name: "Tata Tea", price: 150, category: "Beverages", image: "https://dummyimage.com/300x220/795548/fff&text=Tata+Tea" },
    { name: "Thums Up", price: 40, category: "Beverages", image: "https://dummyimage.com/300x220/212121/fff&text=Thums+Up" },
    { name: "Maaza Mango Drink", price: 45, category: "Beverages", image: "https://dummyimage.com/300x220/ffb300/222&text=Maaza" },
    { name: "Frooti", price: 35, category: "Beverages", image: "https://dummyimage.com/300x220/ffa726/222&text=Frooti" },
    { name: "Rooh Afza", price: 160, category: "Beverages", image: "https://dummyimage.com/300x220/d81b60/fff&text=Rooh+Afza" },

    { name: "Frozen Paratha", price: 110, category: "Frozen Foods", image: "https://dummyimage.com/300x220/c8e6c9/222&text=Frozen+Paratha" },
    { name: "Frozen Samosa", price: 140, category: "Frozen Foods", image: "https://dummyimage.com/300x220/ffcc80/222&text=Samosa" },
    { name: "Frozen Idli", price: 100, category: "Frozen Foods", image: "https://dummyimage.com/300x220/eeeeee/222&text=Idli" },
    { name: "Frozen Dosa Batter", price: 95, category: "Frozen Foods", image: "https://dummyimage.com/300x220/e0f2f1/222&text=Dosa+Batter" },
    { name: "Frozen Naan", price: 120, category: "Frozen Foods", image: "https://dummyimage.com/300x220/ffe0b2/222&text=Naan" },
    { name: "Frozen Paneer Tikka", price: 220, category: "Frozen Foods", image: "https://dummyimage.com/300x220/ef9a9a/222&text=Paneer+Tikka" },

    { name: "Paneer", price: 90, category: "Dairy", image: "https://dummyimage.com/300x220/fffde7/222&text=Paneer" },
    { name: "Curd", price: 35, category: "Dairy", image: "https://dummyimage.com/300x220/e3f2fd/222&text=Curd" },
    { name: "Amul Butter", price: 55, category: "Dairy", image: "https://dummyimage.com/300x220/fff59d/222&text=Butter" },
    { name: "Amul Cheese", price: 95, category: "Dairy", image: "https://dummyimage.com/300x220/ffecb3/222&text=Cheese" },
    { name: "Milk", price: 30, category: "Dairy", image: "https://dummyimage.com/300x220/f5f5f5/222&text=Milk" },
    { name: "Lassi", price: 40, category: "Dairy", image: "https://dummyimage.com/300x220/e1f5fe/222&text=Lassi" },

    { name: "Gulab Jamun Mix", price: 80, category: "Sweets", image: "https://dummyimage.com/300x220/8d6e63/fff&text=Gulab+Jamun" },
    { name: "Rasgulla Tin", price: 170, category: "Sweets", image: "https://dummyimage.com/300x220/fffde7/222&text=Rasgulla" },
    { name: "Soan Papdi", price: 90, category: "Sweets", image: "https://dummyimage.com/300x220/ffe0b2/222&text=Soan+Papdi" },
    { name: "Kaju Katli", price: 300, category: "Sweets", image: "https://dummyimage.com/300x220/e8f5e9/222&text=Kaju+Katli" },
    { name: "Jaggery", price: 70, category: "Sweets", image: "https://dummyimage.com/300x220/a1887f/222&text=Jaggery" },

    { name: "Mango Pickle", price: 95, category: "Pickles & Chutneys", image: "https://dummyimage.com/300x220/ff7043/fff&text=Mango+Pickle" },
    { name: "Lime Pickle", price: 85, category: "Pickles & Chutneys", image: "https://dummyimage.com/300x220/cddc39/222&text=Lime+Pickle" },
    { name: "Garlic Chutney", price: 75, category: "Pickles & Chutneys", image: "https://dummyimage.com/300x220/ef5350/fff&text=Garlic+Chutney" },
    { name: "Coconut Chutney Powder", price: 80, category: "Pickles & Chutneys", image: "https://dummyimage.com/300x220/efebe9/222&text=Chutney+Powder" },

    { name: "Fortune Sunflower Oil", price: 160, category: "Oils & Ghee", image: "https://dummyimage.com/300x220/fff176/222&text=Sunflower+Oil" },
    { name: "Mustard Oil", price: 155, category: "Oils & Ghee", image: "https://dummyimage.com/300x220/fbc02d/222&text=Mustard+Oil" },
    { name: "Coconut Oil", price: 130, category: "Oils & Ghee", image: "https://dummyimage.com/300x220/e0f2f1/222&text=Coconut+Oil" },
    { name: "Amul Ghee", price: 520, category: "Oils & Ghee", image: "https://dummyimage.com/300x220/ffd54f/222&text=Ghee" },

    { name: "Onion", price: 40, category: "Fresh Produce", image: "https://dummyimage.com/300x220/ce93d8/222&text=Onion" },
    { name: "Potato", price: 35, category: "Fresh Produce", image: "https://dummyimage.com/300x220/d7ccc8/222&text=Potato" },
    { name: "Tomato", price: 45, category: "Fresh Produce", image: "https://dummyimage.com/300x220/ef5350/fff&text=Tomato" },
    { name: "Green Chilli", price: 25, category: "Fresh Produce", image: "https://dummyimage.com/300x220/66bb6a/222&text=Green+Chilli" },
    { name: "Coriander Leaves", price: 20, category: "Fresh Produce", image: "https://dummyimage.com/300x220/81c784/222&text=Coriander" },
    { name: "Curry Leaves", price: 15, category: "Fresh Produce", image: "https://dummyimage.com/300x220/388e3c/fff&text=Curry+Leaves" },

    { name: "Agarbatti", price: 30, category: "Pooja Items", image: "https://dummyimage.com/300x220/f8bbd0/222&text=Agarbatti" },
    { name: "Camphor", price: 50, category: "Pooja Items", image: "https://dummyimage.com/300x220/e3f2fd/222&text=Camphor" },
    { name: "Diya", price: 25, category: "Pooja Items", image: "https://dummyimage.com/300x220/ffcc80/222&text=Diya" },
    { name: "Kumkum", price: 20, category: "Pooja Items", image: "https://dummyimage.com/300x220/d32f2f/fff&text=Kumkum" },
    { name: "Haldi Packet", price: 20, category: "Pooja Items", image: "https://dummyimage.com/300x220/fdd835/222&text=Haldi" },
    { name: "Cotton Wicks", price: 35, category: "Pooja Items", image: "https://dummyimage.com/300x220/f5f5f5/222&text=Cotton+Wicks" },

    { name: "Vim Dishwash Bar", price: 20, category: "Household", image: "https://dummyimage.com/300x220/8bc34a/222&text=Vim" },
    { name: "Surf Excel", price: 120, category: "Household", image: "https://dummyimage.com/300x220/90caf9/222&text=Surf+Excel" },
    { name: "Harpic Cleaner", price: 95, category: "Household", image: "https://dummyimage.com/300x220/1565c0/fff&text=Harpic" },
    { name: "Dettol Soap", price: 45, category: "Household", image: "https://dummyimage.com/300x220/a5d6a7/222&text=Dettol" }
];

let cartCount = 0;
let selectedCategory = "All";

const productGrid = document.getElementById("product-grid");
const cartCountText = document.getElementById("cart-count");
const searchInput = document.getElementById("search-input");
const categoryButtons = document.querySelectorAll(".category-btn");

function showProducts(productList) {
    productGrid.innerHTML = "";

    if (productList.length === 0) {
        productGrid.innerHTML = '<p class="no-products">No products found.</p>';
        return;
    }

    productList.forEach(function(product) {
        const card = document.createElement("div");
        card.className = "product-card";

        card.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.category}</p>
            <p class="price">Rs. ${product.price}</p>
            <button onclick="addToCart('${product.name}')">Add to Cart</button>
        `;

        productGrid.appendChild(card);
    });
}

function filterProducts() {
    const searchText = searchInput.value.toLowerCase();

    const filteredProducts = products.filter(function(product) {
        const matchesSearch = product.name.toLowerCase().includes(searchText);
        const matchesCategory = selectedCategory === "All" || product.category === selectedCategory;
        return matchesSearch && matchesCategory;
    });

    showProducts(filteredProducts);
}

function addToCart(productName) {
    cartCount++;
    cartCountText.textContent = cartCount;
    alert(productName + " added to cart!");
}

categoryButtons.forEach(function(button) {
    button.addEventListener("click", function() {
        selectedCategory = button.dataset.category;

        categoryButtons.forEach(function(btn) {
            btn.classList.remove("active");
        });

        button.classList.add("active");
        filterProducts();
    });
});

searchInput.addEventListener("input", filterProducts);

showProducts(products);
